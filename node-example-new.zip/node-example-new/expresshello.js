const express = require('express')
const app = express()
app.get('/ram',(req,res)=>{
    res.send("hello world")
}) 
app.get('/',(req,res)=>{
    res.send("welcome")
}) 
app.post('/',(req,res)=>{
    res.send("welcome in post method")
}) 
app.delete('/',(req,res)=>{
    res.send("welcome in delete method")
})
app.put('/',(req,res)=>{
    res.send("welcome in put method")
})
app.patch('/',(req,res)=>{
    res.send("welcome in patch method")
})
app.listen(3333,()=>{
    console.log('open 33333 port')
})