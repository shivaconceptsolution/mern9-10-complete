var fs = require("fs");
var data = '';
var readerStream = fs.createReadStream('d://demo1.txt');
readerStream.setEncoding('UTF8');
readerStream.on('data', function(s) {
    data += s;
 });

readerStream.on('end',function() {
    console.log(data);
    console.log('Program ended')
 });

 readerStream.on('error', function(err) {
    console.log(err.stack);
 });
 readerStream.on('finish',function(){
    console.log('Program ended')
 })
 //console.log("Program Ended");
 
 

