const { pipeline } = require('stream');
const fs = require('fs');
const zlib = require('zlib');
pipeline(
    fs.createReadStream('d://vd.mkv'),
    zlib.createGzip(),
    fs.createWriteStream('d://vd.mkv.gz'),
    (err) => {
      if (err) {
        console.error('Pipeline failed', err);
      } else {
        console.log('Pipeline succeeded');
      }
    }
  );