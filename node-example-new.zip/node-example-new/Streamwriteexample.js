var fs = require("fs");
var data = 'hello world';
var writeStream = fs.createWriteStream('d://demo2.txt');
writeStream.write(data,'UTF8');
writeStream.end();
// Handle stream events --> finish, and error
writeStream.on('finish', function() {
    console.log("Write completed.");
 });
writeStream.on('error', function(err) {
    console.log(err.stack);
 });
 

 
